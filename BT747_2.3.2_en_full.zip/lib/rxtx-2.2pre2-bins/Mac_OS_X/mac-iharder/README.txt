Information regarding JNILIB found on https://www.sunspotworld.com/forums/viewtopic.php?f=25&t=2176 .
Downloaded from http://iharder.sourceforge.net/current/java/ .
