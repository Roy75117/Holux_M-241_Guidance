﻿
                                 MtkDLut Ver3.36

                               Mar. 2025 (C)4river
                      http://4river.a.la9.jp/gps/indexj.htm

概要
  Transystem: i-Blue747, i-Blue821, 747A+, 747ProS, photoMate 887
  Qstarz: BT-Q1000, BT-Q1000X, BT-Q1300, BT-Q1300ST
  HOLUX: M-241 plus, M-241, RCV-3000, M-1000C, GPSport 245(YUPITERU ASG-1)
    のGPSロガーからログデータをダウンロードします。
  ログやNMEAセンテンスの出力条件も設定できます。

  動作環境
    動作確認済OS: Window 11, Window 10, Window 8。


特徴

  1) USB および Bluetooth経由（機種依存）でダウンロードしてCSVファイルを作成します。
  2) 測位時のデータのみを記録モードに設定できます（機種依存）。
     非測位時はログを記録しないので Flash memoryを節約できます。
  3) M-241のログもインタレストポイントを含む単一のCSVファイルに出力します。
  4) Overwriteモードでフルメモリーになってもレコードの順序が反転しません。
  5) NMEA2KMZ.exeを呼び出してKMZやGPX等に変換できます。
  6) GPSの判定条件と機能をユーザーが追加できます。
  7) コマンドラインオプションで自動ダウンロードが出来ます。
  8) インストールが不要なのでUSBメモリー上で実行できます。
     注）GPSがUSB接続の場合はドライバのインストールが必要です。

インストール

  インストールは実行ファイル MtkDLut.exe を適当なフォルダにコピーするだけです。
  レジストリは使用しないので MtkDLut.exe と MtkDLut.ini の削除でアンインストールできます。
  ジオイド補正を行う場合は別途ジオイドグリッドデータを入手して MtkDLut.exe と同じフォルダに
  コピーする必要があります（設定ファイルの[NMEAoption]セクションのDataPathで別フォルダを指定できます）。
  CustomGeoidユーティリティーを使用してEGM2008から必要なエリアを切り出して使用することも出来ます。

  ジオイド・グリッドデータの入手先。
    EGM2008 2.5'x2.5':
      National Geospatial-Intelligence Agency (NGA)
      NGA: EGM2008 - WGS 84 Version
      http://earth-info.nga.mil/GandG/wgs84/gravitymod/egm2008/egm08_wgs84.html
      2.5 x 2.5-Minute Geoid Undulation Grid in WGS 84 - SMALL ENDIAN
      Und_min2.5x2.5_egm2008_isw=82_WGS84_TideFree_SE.gz を解凍して
      Und_min2.5x2.5_egm2008_isw=82_WGS84_TideFree_SE (149,368,328byte) を得ます。
    EGM2008 1'x1':
      National Geospatial-Intelligence Agency (NGA)
      NGA: EGM2008 - WGS 84 Version
      http://earth-info.nga.mil/GandG/wgs84/gravitymod/egm2008/egm08_wgs84.html
      1 x 1-Minute Geoid Undulation Grid in WGS 84 - SMALL ENDIAN
      Und_min1x1_egm2008_isw=82_WGS84_TideFree_SE.gz  を解凍して
      Und_min1x1_egm2008_isw=82_WGS84_TideFree_SE (933,292,808) を得ます。
        注）EGM2008 2.5'x2.5'との差は約3.5mm以内なので通常は2.5'x2.5'で十分です。
    GSIGEO 2011:
      国土地理院のCD-ROMを入手するかWebサイトからダウンロードします。
      国土地理院 「日本のジオイド2011」(Ver.2.2) ジオイド・モデル データ
      http://www.gsi.go.jp/buturisokuchi/geoid_index.html
      https://fgd.gsi.go.jp/download/geoid.php
      zipファイルを解凍して gsigeo2011_ver2_2.asc (19,670,776byte) を得ます。
        注）ダウンロードにはユーザー登録が必要です。


使用方法

 1. 接続
  「Serial Port」画面で「Com Port」と「Baud Rate」を指定して「Open」ボタンをクリックします。
  「Close」ボタンをクリックするとシリアルポートを切断します。
   ポート番号が不明の場合は「Scan」ボタンをクリックすると有効なポートをスキャンし、GPSロガー
   が見つかるとポートをオープンします。
   Scan時に「Scan and stay of all effective port」がチェックされていると全ての有効ポートを
   スキャンして結果を表示します。

   表示オプション設定
     NMEA:     受信したNMEAセンテンスを表示します。
     MTK:      受信したMTKまたはHLXセンテンスを表示します。
     Log data: 受信したログデータの先頭80文字を表示します。
               先頭に>>が表示されている場合はバイナリーコードを16進表示していることを示します。
     Send Cmd: GPSに送信したコマンドを表示します。

   GPSコマンド
    「Factory」ボタンをクリックするとGPSにファクトリーリセットコマンドを送信し、Fix timeを表示します。
    「Cold」ボタンをクリックするとGPSにコールドスタートコマンドを送信し、Fix timeを表示します。
    「Warm」ボタンをクリックするとGPSにウォームスタートコマンドを送信し、Fix timeを表示します。
    「Hot」 ボタンをクリックするとGPSにホットスタートコマンドを送信し、Fix timeを表示します。


 2. GPSログのダウンロード

  「Log Download」をクリックしてダウンロード画面を開きます。

  「Logger Status」の「Flash ID」の下に「Unknown Flash ID」と表示されている場合は未登録の
   Flash ID なので、設定ファイル MtkDLut.ini に登録が必要です。
   MtkDLut.exeを終了してから後述の「設定ファイル」を修正してください。

     お願い)「Unknown Flash ID」が表示された場合は、Flash ID、Flash容量、GPS機種名を作者までお知らせください。

  「Download」ボタンをクリックするとGPSログのダウンロードを開始します。
   CheckSum Error などでダウンロードが失敗する場合は「Rescue」チェックボックスをチェックしてから再試行してください。
    注1) Bluetooth接続の場合はダウンロード開始までに多少時間がかかります。
    注2)「Rescue」チェックボックスをチェックした場合の動作。
         1) レコードサイズ情報とチェックサムエラーを無視して、すべての有効なデータをダウンロードします。
         2) データ異常で中断した場合にその時点までのデータを保存できます。
         電源トラブルなど不測の事態でデータに不整合が生じた場合に使用します。
        「Rescue」のモードは設定ファイルに保存しません。

   ダウンロード・ブロックサイズの設定
     「Blocks」コンボボックスで１度に読取るMTKロガーのログサイズを指定できます（デフォルトは64kb）。
      ログサイズが64kbより少ない場合はブロックサイズを小さくするとダウンロード時間を短縮できます。
      ログサイズが64kb以上の場合にブロックサイズを64kb以下にするとダウンロード時間が長くなります。
      ダウンロードエラー発生時には小ブロックサイズでのダウンロードをお試しください。
        総ログバイト数 = Record Count * Byte/Record
           Record Count :「Log Download」画面の「Logger Status」グループボックス内の「Record Count:」。
           Byte/Record  :「Log setting」画面下部の「Bytes/Record」ステイタス。

   あらかじめ「CSV」と「NMEA」チェックボックスで出力ファイルの形式を選択しておきます。
   ダウンロードが完了するとSaveダイアログが開くのでファイル名を入力して「保存」ボタンをクリック
   します（「Save Log」ボタンで再度保存することが出来ます）。
   Saveダイアログのファイル名には拡張子名は不要です（指定しても無視されます）。

  「KMZ/GPX」ボタンをクリックするとNMEA2KMZ.exeを呼び出してファイル変換を行います。
   NMEA2KMZ.exeがMtkDLut.exeとは違うフォルダに有る場合は、初回だけオープンダイアログが開くので
   NMEA2KMZ.exeのフォルダを指定してください。
     NMEA2KMZ: http://4river.a.la9.jp/gps/indexj.htm#003

  「KMZ/GPX」チェックボックスをチェックしているとログの保存時に自動的にNMEA2KMZ.exeを起動してファイル変換を行います。
  「/Q」チェックボックスをチェックしていると変換終了後にNMEA2KMZ.exeを閉じます。
     注）「/Q」チェックボックスをオフにするとNMEA2KMZ.exeの設定を変更してから「KMZ/GPX」ボタンで再変換できます。

   ダウンロードの中断は「Cancel」ボタンで行います。
   ダウンロードストリームが終了するまで最大18秒程度の待ち時間を要します。

   ダウンロードの開始でGPSはログ停止状態にセットされるので、ログ記録を開始するには「Start Log」ボタンをクリックします。
     注）GPSによっては「Satrt Log」と「Stop Log」の制御を無視します。

   「Erase Log」ボタンをクリックするとGPSのログを全て消去します。

   Logger Status
     Status:       ログの記録中／停止中の表示。
     Time:         ログ記録時間間隔。
     Distance:     距離によるログのログ間隔。
     Speed:        速度によるログの下限速度。
     Method:       フルメモリー時の停止／上書き。
     Record count: 記録件数。
     Record point: 記録位置(Hex）。
     Version:      バージョン情報。
     Flash ID:     フラッシュメモリーID。
     Fail sector:  不良セクター情報（マウスカーソルを置くと不良パターンを16進表示します）。
                   注）パーセント表示はテーブルサイズ比で表示（実メモリー比では無い）。

   オプション設定
     1)「CSV option」グループボックスで出力項目の指定が出来ます。

      Index:      データ番号を出力します。
      Date+Time: 「TIME」に日付と時刻を出力します。
                  チェックを外すとDateとTimeを個別に出力します。
      N/S,E/W:    緯度経度のN/S,E/Wを独立項目で出力します（LoggerTool互換）。
                  チェックを外すと正負の符号付数値で出力するのでExcel等での処理が容易になります。
      With Units: M, km/h などの単位を出力します（LoggerTool互換）。
                  チェックを外すと数値のみ出力するのでExcel等での処理が容易になります。
      Valid by value: 測位状態を数値で出力します。
                       0 : 測位不可(Invalid)      1 : 測位中(SPS fix)
                       2 : DGPS測位中(DGPS fix)   3 : PPS測位中(PPS fix)
                       4 : RTK測位中(RTK fix)     5 : Float RTK(FloatK fix)
                       6 : 推測航法(Estimated)    7 : 手動入力(Manual input)
                       8 : 模擬モード(Simulator)
      Used,View:  使用／可視衛星数を分離して別項目に出力します。
      Separator:  データ分離要因の項目を追加します。
      Dec.:       CSV出力の緯度経度の小数点以下の桁数を指定します（４～８桁)。

     2)「NMEA option」グループボックスでNMEA出力のオプションが指定できます。

      Lat/Lon:    NMEA出力の緯度経度の小数点以下の桁数を指定します（４～８桁)。
      Alt/Geoid:  NMEA出力の高度とジオイドの小数点以下の桁数を指定します（１～６桁)。
      Geoid model: ジオイドモデルを選択します。
        Fixed value:       位置に関係なく固定値で補正します。
        Custom Geoid:      CustomGeoidユーティリティーで切り出したジオイドファイルを用いて補正します。
        EGM2008 2.5'x2.5': NGAの2.5'x2.5'グリッドデータを用いて補正します。
        EGM2008 1'x1':     NGAの1'x1'グリッドデータを用いて補正します。
        GSIGEO 2011 Ver2:  国土地理院の1'x1.5'グリッドデータを用いて補正します。
                           初回選択時はバイナリーデータに変換するため時間がかかります。
        GSIGEO 2011 Ver1:  国土地理院の1'x1.5'グリッドデータを用いて補正します。
                           初回選択時はバイナリーデータに変換するため時間がかかります。

     注）オプション設定を変更して再度CSVおよびNMEAファイルを出力できます。


 3. ログ条件設定

   「Log setting」をクリックして設定画面を開きます。
    目的のチェックボックスをチェックして「SET」ボタンをクリックするとGPSの設定を更新します。

   「Recording mode」の「Fix only」をチェックすると測位データのみを記録します。
      注）ファームウェア「B-core」以降で有効です。
          BT-Q1300などではこの設定に関係なく測位データのみを記録します。

   「Default」ボタンをクリックするとデフォルトの項目のみチェックされます。
   「Clear all」ボタンをクリックすると全ての項目をクリアします。
   「Select all」ボタンをクリックすると全ての項目をチェックします。
   「SET」ボタンをクリックするまでGPSの設定は更新されません。

   「Refresh」ボタンをクリックするとGPSから現在の設定を読み出して表示を更新します。

   「Method」の「RCR」(Record reason)はインタレストポイントを記録するために必要です。
   「Recording mode」の「Fix Only」をOFFにした場合は非測位を識別するために「Fix mode」の「Valid」
    をチェックする必要があります。

    注1)ログ時間間隔は0.1秒まで設定できますが、１秒以下での動作を保証するものではありません。
    注2)ログ出力に「Date Time」を含まない場合は「by Time」による時間間隔の設定が不正になります。
    注3)ログの開始/停止およびログ条件変更の度に32Byteを消費するので、最大レコード数の表示は目安と考えてください。
    注4)HOLUX M-241の出力項目を変更した場合はHOLUX Logger utilityでは正常にダウンロード出来なくなります。
        この場合はデフォルトの項目設定に戻してください。
    注5)HOLUX M-241ではログ時間間隔を１秒以下にしても、GPSのボタン操作を行うとNMEA出力間隔が１秒に戻ってしまいます。
    注6)BT-Q1300の出力項目を変更した場合はTravel Recorder PC Utility V4では正常にダウンロード出来なくなります。
        この場合はデフォルトの項目設定に戻してください。
    注7)i-Blue747ProS は「Auto Log」の「by Time」を設定してもそれを無視します。
    注8)M-241 Plus, RCV-3000等ではログ条件は変更できません。


 4. NMEA出力設定

   「NMEA setting」をクリックしてNMEA出力設定画面を開きます。

    NMEA setting
      出力したいセンテンスの頻度を設定して「SET」ボタンをクリックするとGPSの設定を更新します。
     「Default」ボタンをクリックするとデフォルトの設定が表示されるので「SET」ボタンをクリック
      するとGPSの設定をデフォルトに設定します。

    DGPS source
      No DGPS : DGPSを使用しない。
      RTCM    : RTCM-SC104によるDGPSを使用する。
      SBAS    : SBAS(Satellite-Based AugmentationSystem)を使用する。

    DGPS mode
      Disable : DGPSモードを無効にする。
      Enable  : DGPSモードを有効にする。

    Baud change
      NMEAポートのボーレートを変更できます。
      右側のドロップダウンボタンをクリックしてボーレートを選択します。

   「Refresh」ボタンをクリックすると現在のGPSの設定を読み出して表示を更新します。

    センテンスの周期は「Period」欄で mS単位で設定できますが通常は 1000mSとします。

    注）出力周期は100mSまで設定できますが動作を保証するものではありません。
        GPSによっては設定を無視するか、ハングアップする可能性が有ります。

   「Update RTC」ボタンをクリックするとGPS RTCタイマを現在時刻に設定します。
    これはEOWロールオーバーで日付が不正になった場合に使用します
      注1) うるう秒の補正が完了するまでGPS時刻が数秒進みます（Fix後最大12分程度）。
      注2) バッテリーの消耗で再設定が必要になる場合があります。
      注3) 古いチップセットでは更新されるまでに数十秒を要します。
      注4) 設定ファイルの[Option] セクション「RTCfix」が「1」なら必要な場合に自動実行します。
 

 5. AGPS設定機能

    GPSがAGPSをサポートしている場合は「AGPS setting]ボタンが表示されるので、クリックして設定画面を開きます。
    AGPSデータファイルはHTTPまたはFTPサーバーまたはローカルPCファイルから取得できます。
   「Update」ボタンをクリックするとAGPSデータを取得しGPSに送信します。
   「Query」ボタンをクリックすると現在のAGPS有効期限等を表示します。
   「Reset」ボタンをクリックするとGPS受信機のAGPS情報をクリアします。
   「Save」をチェックするとEPOデータをファイルとして保存します（保存先は「Local File」の「File name」と同じフォルダ）。
    14日分のデータを含む MTK14.EPO を保存しておくと、オフラインのPCで約14日間AGPSを有効に出来ます。
    EPOファイルをドラッグすると「AGPS File」の「File name」にファイル名をセットします。
      注1）Proxy server の「Auto setting」をチェックしても正しい情報が得られない場合があります。
           この場合はチェックをオフにして手動設定してください。
      注2）Bluetooth接続ではデータ転送に長時間を要します。
           できるだけUSB接続で実行してください。
      注3) HTTPサーバーURLはEPOファイル名付きで指定します。
            例) https://xxxxx.com/EPO/MTK7d.EPO

 6. 終了

   「Exit」をクリックします。


 7. コマンドラインオプション

    設定ファイルの他に /A /D /G /Q を使用できます。

     /A ログを自動的にダウンロードします。
        ログファイル名はデータの開始時刻から作成します。
        フォーマットは設定ファイルの [FileName]セクションで指定できます。
        保存フォルダは設定ファイルの [Option]セクションの SaveFolder で指定できます。
     /D ログ保存後にGPSのログデータを消去します（非推奨）。
          警告）アクシデントでログデータを失う恐れがあります。
     /G AGPSデータをダウンロードして更新します。
     /Q 自動終了します。

     例）MtkDLut.exe /A /Q
         MtkDLut.exe Test.ini /A /Q

     参考) コマンドラインオプションは実行ファイルのショートカットにも適用出来ます。
           ショートカットを右クリックしてプロパティを選択し、「リンク先」の末尾にコマンドラインオプションを追加します。
           目的別に複数のショーカットを作成しておくと便利です。


出力CSVファイルの追加項目

   「SEPARATOR」フィールド
    データの分離要因を１文字の組み合わせで表します。
      L : Logger Start/Stop.
      F : Format Register.
      T : Auto Log by Second.
      D : Auto Log by Distance.
      S : Auto Log By Speed.
      M : Recording Method Overwrite/Stop.


設定ファイル MtkDLut.ini

    終了時のオプション設定を実行ファイルと同一フォルダの MtkDLut.ini に保存します。

    実行ファイル(MtkDLut.exe)の有るフォルダが書込み禁止の場合は下記のフォルダにコピーして使用します。
      C:\Users\[User name]\AppData\Local\VirtualStore\[MtkDLut folder]\MtkDLut.ini

        [User name]はDOSプロンプトで echo %USERNAME%<Enter> とタイプすると表示されるフォルダです。
        [MtkDLut folder]はMtkDLut.exeが有るフォルダです。

    複数の設定ファイルを保存しておきコマンドラインまたはドラッグ&ドロップで選択することが出来ます。
    シリアルポートオープン中のドラッグは禁止されます。

  1. [Flash ID] セクション
     GPSロガーのログ容量とFlash IDの対応を登録します。
     1MByteから16MByteまで登録可能です。
       8MB=xxxxxxx,yyyyyy,zzzzzz
     のようにカンマ(,)で区切って複数のFlash IDを登録できます。
     2MByteと4MByteのFlash IDが登録済です。

  2. [Font] セクション
     フォント名とサイズを指定できます。
     フォントやサイズによっては表示領域からはみ出すので注意してください。

  3. [Option] セクション
     NMEA2KMZop :   NMEA2KMZ.exe に渡すオプションパラメータを設定できます（/Q は無効）。
                    設定ファイル（.ini）の指定を追加することもできます。
                    設定ファイルがNMEA2KMZ.exeと同一フォルダにない場合はフルパスで記述すること。
                      注）NMEA2KMZ.exeを起動中の場合は設定ファイル（.ini）のみが有効です。
     MaxSNR :       SNR棒グラフの最大スケールを指定します。
     MemoMaxLine:   NMAEセンテンス表示行数の最大値を指定できます。
     LogDateOffset: ログデータの日付オフセット（デフォルト値は 25569 =1970年）。
                    注）バイナリーログ形式のGPSの場合は[GPS_Data]セクションでGPS機種毎に設定できます。
     EOWfix:        記録済のログデータに対するEOW対策の有効／無効を指定する。
                      1 = EOW対策を行う（デフォルト）。
                      0 = 対策しない。
                      処理の概要 :
                         While (Now - LogTime) > 1024*7 Do LogTime := LogTime + 1024*7
     RTCfix:        GPSのRTCタイマ自動修正有効／無効を指定する。
                      1 = 自動修正を行う（デフォルト）。
                            注）修正してもバッテリーが消耗すると元に戻ります。
                      0 = 修正しない。
     TimeVerification: ログ時刻チェックの有効／無効を指定する。
                         1 = チェックが有効（デフォルト）。
                         0 = チェックしない。
              注）オプションの TimeVerification=1 で日付時刻が下記の場合はデータを破棄します。
                  1) 1978/2/22以前の時刻（Holux GPSの場合は 2000/1/1以前の時刻）。
                  2) 現在時刻より１時間以上進んでいる。
     SkipOneTrack:  M-241 Plus または RCV-3000 の場合に 1 にするとTrack数が１の場合はトラック選択画面を表示しない。
     MaxBaud:       シリアルポートスキャンの最大ボーレート。


  4. [CSVoption] セクション
     AltitudeDecimal: CSV出力の標高の小数点下桁数を指定します(1～8桁)。
     SpeedDecimal:    CSV出力の速度の小数点下桁数を指定します(1～8桁)。
     WithGPSname:    「1」のときCSVファイルのINDEXにGPS名称を出力する。
                     「0」ならGPS名称を出力しない。

  5. [NMEAoption] セクション
     WPL_Prefix:      POIに対するNMEAのWPLセンテンスのポイント名プリフィックスを指定できます。
     LatLonDecimal:   NMEA出力の緯度経度の小数点下桁数を指定します(1～8桁)。
     AltitudeDecimal: NMEA出力の標高の小数点下桁数を指定します(1～8桁)。
     SpeedDecimal:    CSV出力の速度の小数点下桁数を指定します(1～8桁)。
     GeoidModel:      選択中のジオイドモデル。
     DataPath:        ジオイドグリッドデータのあるパスを指定します。
                      空の場合は実行ファイルと同一フォルダとみなします。
     Geoid:           固定ジオイド値（ｍ）。

  6. [GPS_Data] セクション
     リリース情報とGPS名称などの対応を指定できます。

     書式
       GPS_ID = GPS_Name, Def_BitMask, ShortLog, Logging_Mode, Logging_Start/Stop, EPO_rec, KeepAwake_Command, Altitude mode

     内容
       GPS_ID
         バイナリーログ形式のGPSの場合 :
           $PHLX810*35 コマンドに対するアンサーを用いる。
             例）アンサーが $PHLX852,M241Plus*5F の場合は M241Plus。
           ファームウェア別に記述する場合は末尾に$PHLX829コマンドのアンサーバージョンを"/"で区切って付加します。
             例）$PHLX829*3F コマンドに対するアンサーが $PHLX861,104*2A の場合は M241Plus/104。

         テキストログ形式のGPSの場合 :
           リリース情報($PMTK705)の第４（または第３）パラメータ。
           第3パラメータを含まない場合の特例。
             M-core  : 第１パラメータが"M-core"で始まる場合に適用する。
             B-core  : 第１パラメータが"B-core"で始まる場合に適用する。
             Unknown : 上記に該当しない場合。

       GPS_Name
         表示用GPS名称。

       Def_BitMask
         デフォルトの記録項目設定用ビットマスク(Hex)。
         現在の値は「Log setting」画面下部に表示されます。
           Bit31: Only the Fix data is recorded.
           Bit19: Distance.
           Bit18: millisecond.
           Bit17: RCR (Record Reason).
           Bit16: SNR (要SID).
           Bit15: Azimuth (要SID).
           Bit14: Elevation (要SID).
           Bit13: SID.
           Bit12: Nsat.
           Bit11: VDOP.
           Bit10: HDOP.
           Bit9 : PDOP.
           Bit8 : DGPS age.
           Bit7 : DGPS station.
           Bit6 : Heading.
           Bit5 : Speed.
           Bit4 : Height.
           Bit3 : Longitude.
           Bit2 : Latitude.
           Bit1 : Valid.
           Bit0 : UTC.
        注）ログデータがバイナリーモード（M-241 Plusなど）の場合はFlagに対するPOIのビットマスク（16進表記）を指定します。

       ShortLog
         0: Standard:   Lat./Long. 8byte Double, Speed 4byte Single,  Height 4byte Single。
         1: M-241:      Lat./Long. 4byte Single, Height 3byte Single。
                        セパレータとウェイポイントが 32バイト。
         2: M-1000C:    Lat./Long. 4byte Single, Speed 4byte Integer(cm/Sec), Height 3byte Single。
                        セパレータとウェイポイントが 32バイト。高度と速度の順序が逆。
         3: M-241 Firmware Ver1.13:
                        Lat./Long. 4byte Single, Height 3byte Single, Speed 4byte Single。
                        セパレータとウェイポイントが 40バイト。
         4: GPSport 245, ASG-1:
                        Lat./Long. 4byte Single, Speed 3byte Integer(256*cm/Sec), Height 4byte Single。
                        セパレータとウェイポイントが 40バイト。高度と速度の順序が逆。
         5: M-1000C Firmware Ver1.03:
                        Lat./Long. 4byte Single, Speed 4byte Integer(cm/Sec), Height 3byte Single。
                        セパレータとウェイポイントが 40バイト。高度と速度の順序が逆。
         6: 747ProS:    Standardと同じデータ形式。
                        Smartモードと Carモードの２種類の条件設定。

         7: Binary mode: 右シフトCRC（左シフト用テーブル使用） Illegal (M-241 Plus, RCV-3000)
         8: Binary mode: 左シフトCRC（左シフト用テーブル使用） Standard CRC32
         9: Binary mode: 右シフトCRC（右シフト用テーブル使用） Standard CRC32
        10: Binary mode: 左シフトCRC（右シフト用テーブル使用） Illegal
             CRC多項式： X^32+X^26+X^23+X^22+X^16+X^12+X^11+X^10+X^8+X^7+X^5+X^4+X^2+X^1+1
             初期値   ： 0xFFFFFFFF

       Logging_Mode
         0: Fix + NonFix
         1: Fix Only
         2: Programmable

       Logging_Start/Stop
         0: Not supported
         1: Supported
         2: Limited

       EPO_rec
         AGPS情報のレコード容量 (4Rec/Day)。
         デフォルトは 28（７日分）。

       KeepAwake_Command
         スリープ防止コマンド（二重引用符「"」で囲む）。

       Altitude mode
         0: WGS-84楕円体からの高度。
         1: 海抜高度。
            GPS名称の右側に「(MSL Alt)」を表示し、ジオイド高を減算しません。

     例）01017-00E=M-241,8000001D,1,2,1,,"$HOLUX241,6",1
         TSI_887=photoMate887,0002003F,0,1,0,28,

     Binary mode の場合の追加情報。
       データ構成とインデックス構成をユーザーが指定できます。
        |<データ位置>|<データ形式>|<データ除数>|<データ加算値>|<インデックス位置>|<インデックス形式>|<インデックス除数>|<インデックス加算値>|<レコードサイズ>

       データ位置  ：ログデータの開始位置を指定する。
                      データ順序： Date time, Latitude, Longitude, Altitude, Speed, Flag
                                   データ無しの項目はブランクまたはゼロにすること。
                                     例）|1,5,9,13,15,18|

                      ユーザーは末尾に項目を追加できます（４項目まで: Aux1～Aux4）。
                          例）|1,5,9,13,15,18,19,21,23,25|
                        数値の直後にコロン(:)で区切って名称を指定できます。
                        名称を指定しない場合はAux1～Aux4が割り振られます。
                          例）|1,5,9,13,15,18,19:Heartrate,21:Altimeter,23:Heading,25:Distance|
                        数値に小数点と数値１桁（.0～.9）を付加して少数点以下の桁数を指定できます（省略した場合は０桁）。
                          例）|1,5,9,13,15,18,19:Heartrate,21.1:Altimeter,23.1:Heading,25.3:Distance|

                        注１）追加した項目はCSVファイルにのみ出力されます。
                        注２）項目名、少数点下桁数の指定は追加項目のみに有効です。
                        注３）追加できる項目内容は数値のみです。

       データ形式  ：元データの形式を指定する（末尾の数値はバイト数）。
                      S4,S3,S2,S1: 符号付整数
                      U4,U3,U2,U1: 符号なし整数
                      F8,F4,F3:    浮動小数点（F3はF4の下位１バイトを省略したもの）
       データ除数  ：データを除算する値
       データ加算値：データに加算する値

       インデックス位置  ：インデックスデータの開始位置を指定する。
                            データ順序： Start Time, Time Length, Record point, Record count
       インデックス      ：元データの形式を指定する（末尾の数値はバイト数）。
                            S4,S3,S2,S1: 符号付整数。
                            U4,U3,U2,S1: 符号なし整数。
                            F8,F4,F3:    浮動小数点（F3はF4の下位１バイトを省略したもの）。
       インデックス除数  ：データを除算する値。
       インデックス加算値：データに加算する値。

       レコードサイズ： データ１レコード当たりのバイト数、データ１ブロックの最大レコード数、
                        インデックス1レコード当たりのバイト数、インデックス１ブロックの最大レコード数、最大ログ容量
                          デフォルト値）64,32,32,64,253952

       例）M241Plus=M-241 Plus,10,7,1,,,,0|1,5,9,13,15,18|U4,F4,F4,S2,U2,U1|86400,,,,10,|36526,,,,,|17,21,29,33|U4,U4,U4,U4|86400,,,|36526,,,
             時刻は T = t / 86400 + 36526 で計算される。 
             速度は S = s / 10 で計算される。

       16進ダンプ機能。
         Aux1～Aux4のデータ位置の末尾に"x"または"X"を付加すると数値を16進表示します（整数：U1-U4, S1-S3の場合のみ）。
         "x" : Little endian（信号受信シーケンス通りで表示）。
         "X" : Big endian。
           例）1～16バイトのダンプ
              M241Plus=Dump 01-16,10,7,1,,,,0|1,5,9,13,15,18,1x,5x,9x,13x|U4,F4,F4,S2,U2,U1,U4,U4,U4,U4|86400,,,,10,|36526,,,,,|17,21,29,33|U4,U4,U4,U4|86400,,,|36526,,,
           例）17～32バイトのダンプ
              M241Plus=Dump 17-32,10,7,1,,,,0|1,5,9,13,15,18,17x,21x,25x,29x|U4,F4,F4,S2,U2,U1,U4,U4,U4,U4|86400,,,,10,|36526,,,,,|17,21,29,33|U4,U4,U4,U4|86400,,,|36526,,,

      未登録ロガーの場合の処理。
        トラック数問い合わせコマンド（$PHLX701）に応答があれはバイナリー転送ロガーとみなして
        DefaultBin=Unknown GPS (Binary mode), ... の設定を適用します。

  7. [EGM2008_25],[EGM2008_10] セクション
     title: ジオイドモデルのタイトル名
     fname: ジオイドモデルのファイル名
     nrows: Y方向のデータ数
     ncols: X方向のデータ数
     glamn: 最南端の緯度
     glomn: 最西端の経度
     dgla:  緯度のデータステップ（度）
     dglo:  経度のデータステップ（度）
     nlat:  緯度方向の有効データ数
     nlon:  経度方向の有効データ数
     PrePad: 経度先頭の無効データ数

  8. [GSI] セクション
     title: タイトル名（セミコロンで区切って複数を記述できる）
     fname: ファイル名（セミコロンで区切って複数を記述できる）
     nrows: Y方向のデータ数
     ncols: X方向のデータ数
     glamn: 最南端の緯度
     glomn: 最西端の経度
     dgla:  緯度のデータステップ（度）
     dglo:  経度のデータステップ（度）
     nlat:  緯度方向の有効データ数
     nlon:  経度方向の有効データ数
     PrePad: 経度先頭の無効データ数
     Spline: スプライン補間を用いる

  9. [FileName] セクション
     自動ダウンロード時の保存ファイル名を指定します。
     任意の文字列を挿入するには「<」と「>」で囲みます。

     UTC_Time:     1でUTC、0でローカルタイム。
     Time_fortmat: 日付時刻のフォーマットを指定します。
                   下記の特殊文字が有効です。
                   y: 年、m: 月、d: 日、h: 時、n: 分、s: 秒
                     例）yyyy-mm-dd_hh-nn-ss
                         mm-dd-yyyy_hh-nn-ss
                         yyyymmdd_hhnnss
                         <GPS1_>yyyymmdd_hhnnss
                         <FixdName>

M-241 Plus Ver1.04 と RCV-3000 Ver1.02 での制限事項
  1. Bluetooth経由のダウンロードはできない。
  2. Log setting
     Recording method, Auto Log のみが設定可能。
  3. NMEA setting
     Period(mS), DGPS source, DGPS mode, Baud change のみが設定可能。
       注）ボーレートを115200bpsに変更するとダウンロード時間が半減しますが、
           それ以上にしても高速にならず不安定になります。
           この場合は「Exit」ボタンで終了し、再起動後にRS-232Cの「Scan」を実行してください。
       警告）HOLUX ezTour for Logger を使用する場合はボーレートを38400bpsに戻してください。


MTK GPSロガー仕様一覧表
  http://4river.a.la9.jp/gps/gps_specj.htm


トラブルシューティング

  1. シリアルポートに接続できない。
     USBケーブルを取り外して再接続してみてください。
     USB接続時はタイムアウトによってGPSがスリープモードになることがあるのでログ記録状態にしてください
     （特に旧タイプの i-Blue747, BT-Q1000 など）。
     USB接続の場合は通信速度を正しく設定する必要が有ります。

  2. Logger Tool V2.5 のCSV出力と値が異なっている。
     丸め誤差のため数値の最下位に±１の差異を生じる場合があります。
     PDOP, VDOP, HDOPの小数点下１桁目のゼロは正しく出力されています。
     負の値のゼロサプレスの仕様が異なる部分があります。
     RMCセンテンスの80年は2080年ではなく、1980年として出力しています。

  3. ダウンロードしたレコード数が「Record Count」より少ない。
     GPSロガーのデータに無効データやエラーが含まれている場合があります（電源の強制断などによる）。

  4. Bluetooth経由でダウンロード出来ない。
     i-Blue747, BT-Q1000, M-241 plus, RCV-3000 は Bluetooth経由でのダウンロードが出来ません。

  5. USB接続でダウンロード出来ない。
     通信速度を正しく設定する必要があります。
     GPSのモードを「LOG」モードにして試してください。

  6. NMEA出力のGSAセンテンスの衛星数が実際と異なる。
     ロガー出力には非使用の衛星が省略される場合があります。

  7. CheckSum Error などでダウンロードが失敗する。
    「Rescue」チェックボックスをチェックしてからダウンロードしてください。
       注）データの完全性は保証されません。
     ダウンロード・ブロックサイズ「Blocks」を小さくすると改善されるかも知れません。


使用コンパイラ
  Embarcadero Delphi 12.1 Community Edition を使用しています。

  またフリー・コンポーネント
    CommX Ver1.06  エックス (KYY06770)氏作 ＲＳ２３２Ｃ通信コンポーネント COMMX106.LZH を使用しています。
    非常に有用なコンポーネントを提供された作者の方に感謝いたします。


リリースノート
・このアプリケーションはフリーソフトウェアです。
・再配布は自由ですが実行ファイルとドキュメントを含めて配布願います。
・作者はこのアプリケーションの使用または配布によって生じた、いかなる損失及び障害に対しても一切の責任を負いません。


変更履歴

 Ver3.36
   1. Windowsの「日付と時刻の形式」を変更した場合の不具合を修正した。

 Ver3.35
   1. 日本のジオイドモデル GSIGEO 2011 ver2.2 をメニューに追加した（硫黄島のジオイドが追加されている）。

 Ver3.34
   1. FEP ON/OFF での異常終了対策を廃止した。

 Ver3.33
   1. 日本のジオイドモデル GSIGEO 2011 ver2.1 をメニューに追加した。

 Ver3.32
   1. Windows 11 バージョン22H2 日本語版で FEP ON/OFF での異常終了を防止した。

 Ver3.31
   1. HTPPSアクセス用の SSL library (ssleay32.dll と libeay32.dll)を不要にした。

 Ver3.30
   1. MTKロガーの１回あたりの読取りサイズを指定できるようにした。
   2. レスキューモードではログデータのヘッダーが欠落したデータも読込むようにした。

 Ver3.29
   1. MTKロガーのレスキューモードの読込みを強化した。
      レコード単位のチェックサムエラーが有った場合はポイントを１文字ずつ進めて繰り返して再試行を行うようにした。
   2. ログのダウンロード時に過剰にRTCタイマを更新するバグを修正した。

 Ver3.28
   1. レスキューモードではチェックサムエラーを無視するようにした。
   2. ダイアログメッセージとヒント表示を日本語にした（日本語ロケール以外では英語表示）。

 Ver3.27
   1. GPS電波無しの場合は時刻不正なログのダウンロード後にGPS RTCタイマを現在時刻に設定するようにした。

 Ver3.26
   1. GPS時刻のEOWロールオーバーの自動修正を可能にした（バッテリー消耗で元に戻る）。

 Ver3.25
   1. 未登録のロガーでAGPSデータをダウンロードできないバグを修正した。

 Ver3.24
   1. RTCタイマーの更新機能を追加した（EOWロールオーバー対策）。
     「NMEA setting」→「Update RTC」

 Ver3.23
   1. EPOファイルをHTTPホストからダウンロード可能にした。

 Ver3.22
   1. 起動済のNMEA2KMZ.exeに渡すファイル名が文字化けするバグを修正した。
   2. NMEA2KMZ.exeを自動起動するチェックボックスを追加した。
   3. NMEA2KMZ.exeを自動終了するチェックボックスを追加した。
   4. 「KML/KMZ」ボタンのキャプションを「KMZ/GPX」に変更した。

 Ver3.21
   1. オープン／セーブダイアログをメインフォームの中央に表示するようにした。

 Ver3.20
   1. マルチディスプレイをサポートした。

 Ver3.19
   1. 高DPIディスプレイでの表示対策を行った。
      ChangeMani.exeでマニフェストを書き換えると高DPIディスプレイで縮小表示が可能になります。
      http://4river.a.la9.jp/gps/file/ChangeManij.htm
   2. コンパイラを Delphi 10.3 Starter に変更した。

 Ver3.18
   1. シリアルポートスキャンを改善した。
      初期ポーレートで無検出の場合は高速から低速に向かって再スキャンするようにした。
      最高ボーレートは設定ファイルの[Option]セクションの「MaxBaud」で指定できる（デフォルトは 115200bps）。
   2. ボーレートプルダウンメニューのDropDownCount数を増加した。 

 Ver3.17
   1. Holux M-241 Plus のログモード(Overwrite/Stop)を切り替えた場合にLCD表示が更新されないバグを修正した。

 Ver3.16
   1. バイナリー形式ロガーに対する機能を改善した。
      ダウンロードを高速化した（ループ中の無駄なウエイトを廃止）。
      最終経過時間に60分以上が表示されないバグを修正した。

 Ver3.15
   1. 設定ファイルの[GPS_Data]セクションのバイナリー形式ロガーに対する記述を拡張。
      GPS_IDに Product Name を使用できるようにした。
      設定をファームウェアバージョン毎に記述可能にした。
      Aux1～Aux4に16進ダンプ機能を追加した。
   2. Track Selectフォームの高さをマウスドラッグで変更可能にした。

 Ver3.14
   1. Holux RCV-3000 をサポートした。
   2. Holux M-241 Plus Ver1.04 をサポートした。
   3. バイナリーログ形式GPSのログ容量は機種毎に設定ファイルで定義できるようにした。
   4. バイナリーログ形式GPSのCRCモードを設定ファイルで指定できるようにした。
   5. ダウンロード時間と残り時間の分を60分以上表示可能にした。

 Ver3.13
   1. M-241 Plus からダウンロード時の CRCエラー処理のバグを修正した。
   2. バイナリーログ形式の諸元を設定ファイルで指定できるようにした。
      ユーザー自身でログフォーマットやテータ形式のバリエーションに柔軟に対応できます。
   3. バイナリーログ形式の場合はユーザー定義項目を４項目まで追加可能にした。

 Ver3.12
   1. M-241 Plus F/W Ver1.03 をサポートした。
   2. M-241 Plus のダウンロード時にタスクバーのプログレス表示を追加した。

Ver3.11
   1. M-241 Plus に対するサポートを改善した。
      ダウンロード時に残り時間を表示するようにした。
      ダウンロード中のトラック番号表示を追加した。
      緯度が±90度以外または経度が±180度以外の場合はデータを無視するようにした。

Ver3.10
   1. M-241 Plus に対するサポートを改善した。
      ログポイント数の表示にパーセント表示を追加した。
      ログ消去時にデッドロックするバグを修正した。

Ver3.09
   1. Holux M-241 Plusをサポートした。
      [Option]セクションの SkipOneTrackの値を 1 にするとTrack数が１の場合はトラック選択画面を表示しない。
   2. /A と /Q コマンドラインオプション使用時はログファイルを強制上書きするようにした。 

Ver3.08
   1. シリアルポートリストから使用中のポートを削除するようにした（レスポンスが低下するのでBluetoothは確認しない）。

Ver3.07
   1. NMEA出力センテンスの緯度経度の整数部分を固定桁数に変更した。

Ver3.06
   1. KML/KMZボタンが無効になっているエンバグを修正した (Ver3.04 と Ver3.05)。

Ver3.05
   1. 地域によって日付表示が不正になるバグを修正した。
   2. FlashID2MB の 1C30151C を 1C20151C に修正した。

Ver3.04
   1. FlashID2MB に 1C30151C を追加した。

Ver3.03
   1. タスクバーアイコンへのプログレス表示を追加した（Windows 7以降）。
   2. コンパイラを Delphi 10.2 Starter に変更した。

Ver3.02
   1. HOLUX社 GR-241 (M-241 日本語/英語)をサポートした。
      設定ファイルの[GPS_Data]セクションに下記を追加した。
        GR241=GR-241(M-241 Jpn/Eng),8000003D,3,2,1,,"$HOLUX241,6",1

Ver3.01
   1. GSIGEO 2011 Ver2 をサポートした。
   2. ジオイドモデル選択プルダウンリストでのジオイドモデル名を設定ファイルで指定できるようにした。

Ver3.00
   1. EOW問題の対策を行った。
   2. 設定ファイルの文字コードをUNICODEに変更した（既存の設定ファイルは変更しない）。
   3. コンパイラを Delphi 10.1 Berlin に変更した。

Ver2.07
   1. シリアルポート選択時にFriendlyNameを表示するようにした。

Ver2.06
   1. ログ時刻チェックの有効／無効を指定するオプションを追加した（TimeVerification）。
   2. マニュアル加筆。

Ver2.05
   1. ポートスキャンで実在しないポートをスキャンしないようにした。
   2. ボーレートに 230400bps と 460800bps を追加した。
   3. 設定ファイルの[Option]セクションに"LogDateOffset"を追加した。

Ver2.04
   1. HOLUXロガーのWaypointが認識されないバグを修正した。
   2. ボーレートに 230400bps と 460800bps を追加した。

Ver2.03
   1. チェックサムエラー発生時は直近にDynamic setting patternが有れば再同期するようにした。
   2. HOLUX社製ロガーのDynamic setting pattern先頭部分の欠落に対応した。

Ver2.02
   1. 連続する"FF"によるデータのリジェクトをM-241に限定した。<BR>
   2. ダウンロード中にSerial Portパネルを開いてもダウンロードを中断しないようにした。

Ver2.01
   1. ハングアップを防止するために SaveDialogを旧タイプに変更した。

Ver2.00
   1. HOLUX M-241のダウンロード処理を改善した。
      通信データに"FF"が連続する場合の処理を修正した。
   2. データに内部エラーが有る場合は無視するようにした（中断しない）。

Ver1.45
   1. Fail sectorが有る場合にレコード数が制限されるバグを修正した。
   2. Fail sectorのパーセント表示を追加した。

Ver1.44
   1. ログメモリーフルのクリア対策を強化した。

Ver1.43
   1. 「Recording Method」が「Stop」でログメモリーフルの場合にログ消去が出来ないバグを修正した。

Ver1.42
   1. 「日本のジオイド2011」（Ver.1）「gsigeo2011_ver1.asc」をサポートした。
   2. Galileoセンテンスをサポートした。

 Ver1.41
   1. NMEA settingパネル選択時に表示内容を更新するようにした。

 Ver1.40
   1. BDS(BeiDou Navigation Satellite System)センテンスに対応した。

 Ver1.39
   1. GSIGEO 2000 のデフォルトを 日本のジオイド2011+2000 (gsigeo20112000.asc) に変更した。

 Ver1.38
   1. ディスプレイのDPIを変更した場合にレイアウトが崩れないようにした（フォントサイズの調整は必要）。

 Ver1.37
   1. コマンド送信タイミングを修正した。
   2. NMEA出力のGPGSVセンテンスでSNRのゼロをブランクに変更した。

 Ver1.36 May. 2013
   1. ログ消去タイミングをログ項目変更後に変更した。
   2. ログにPDOPまたはVDOPが含まれる場合はNMEA出力にGPGSAセンテンスを含めるようにした。

 Ver1.35 Feb. 2013
   1. ポートスキャンでボーレートもサーチするようにした。
   2. 可視衛星バーグラフを可変表示にした。
   3. Factory resetボタンを追加した。
   4. BT-Q1300ST をサポートした。

 Ver1.34 Dec. 2012
   1. ログデータ削除直後にログカウントがゼロで無い場合にログ条件設定をスキップするバグを修正。
   2. ログ条件取得タイミングを調整した。

 Ver1.33 Dec. 2012
   1. 747ProS の Auto Log チェックボックス表示のバグを修正。

 Ver1.32 Dec. 2012
   1. 747ProS に対応した。
   2. M-241の GPS_ID = 01029-00E に対応した。
   3. Logger Status の Versin表示を修正（Hex->Dec)

 Ver1.31 Aug. 2012
   1. Hanwha Pocket GPS S1 (PG-S1)への AGPS送信バグを修正（ログ停止、GPS情報非表示）。
      $PMTK705センテンスに第三パラメータ（機種名）がない機種は"Change UART Format Packet"コマンドのボーレートを0bpsにした。

 Ver1.30 Feb. 2012
   1. GPSのNMEAボーレートを変更できるようにした。
   2. シリアルポートのオープン時にバイナリモードだったらNMEAモードに自動切替するようにした。
   3. "Change UART Format Packet"コマンドにボーレートを含めた。

 Ver1.29 Nov. 2011
   1. Holux M-1000C ファームウェアVer1.04 に対応した。
   2. ログクリアでプログレスバー表示等を初期化するようにした。
   3. シリアルポート・オープンでAGPSステイタスをクリアするようにした。

 Ver1.28 Apr. 2011
   1. Transystem i-Blue747ProS に対応した。
   2. 国土地理院の「日本のジオイド2000 Ver.5」に対応した。

 Ver1.27 Jun. 2010
   1. AGPS送出タイミングマージンを大きくした。

 Ver1.26 Jun. 2010
   1. Hanwha Pocket GPS S1 (PG-S1) の AGPSに対応した。
      最大で17日間有効。

 Ver1.25 Mar. 2010
   1. NMEA設定の「Default」で周期を１秒にリセットするようにした。
   2. NMEA周期を100mS(10Hz)まで設定可能にした。
   3. NMEA出力項目の制限を解除した。
   4. ポートスキャン時のロガー検出を無効にした。
   5. HOLUX M-1000C Ver1.03 2010-04-13版に対応した。

 Ver1.24 Feb. 2010
   1. M-1000C Firmware Ver1.03 対応のバグを修正した。

 Ver1.23 Dec. 2009
   1. M-1000C Firmware Ver1.03 に対応した。
   2. カスタムジオイドファイルのサイズチェックを行うようにした。

 Ver1.22 Dec. 2009
   1. Customジオイドファイルに対応した。
   2. NMEAセンテンスの最大表示行数を設定ファイルで指定できるようにした。

 Ver 1.21 Nov. 2009
   1. CSVの使用／可視衛星数を別項目に出力可能にした。

 Ver 1.20 Nov. 2009
   1. Holux GPSport 245（YUPITERU ASG-1）をサポートした。
      ユーザーレポートとご協力により実装しました。
   2. Holuxロガーのメモリー容量の計算を修正した。

 Ver 1.19 Nov. 2009
   1. /A 無しでの /D コマンドラインオプションを有効にした。
   2. 自動生成ファイル名に任意の文字列を挿入可能にした。
   3. ログファイル名の初期設定をローカルタイムに変更した。

 Ver 1.18 Oct. 2009
   1. 自動操作用コマンドラインオプションを追加した。
   2. 出力ファイル形式の選択方法を変更した。
   3. 新ファーム photoMate887 の FlashIDに対応した。

 Ver 1.17 Sep. 2009
  1. Holux M-241ファームウェア Ver1.13 に対応した。

 Ver 1.16 Sep. 2009
   1. EPOファイルの送信タイミングマージンを大きくした。
   2. 国土地理院およびNational Geospatial-Intelligence Agency (NGA) のジオイド・モデル データに対応。
      NMEAデータのジオイドを緯度経度に対応して出力するようにした。

 Ver 1.15 Jul. 2009
   1. photoMate 887, M-1000C をサポートした。
   2. PROXY自動設定でポートが 80, 8080の時は 21 に変換するようにした。
   3. UsedSat, Altitude, Geoid の表示を追加した。
   4. シリアルポートをクローズしている時は他の画面に移動しないようにした。
   5. ロガーでない場合はダウンロードとログ設定画面を開けないようにした。

 Ver 1.14 Feb. 2009
   1. M-241 Firmware V1.11 に未対応のバグを修正した。

 Ver 1.13 Feb. 2009
   1. GPS名称などの情報を設定ファイルで指定できるようにした（ユーザーが追加可能）。
   2. BitMask値の表示を追加した。
   3. NMEA設定の Defaultボタンの機能を変更した。
   4. CSVファイルのINDEXにGPS名称を出力するようにした。

 Ver 1.12 Jan. 2009
   1. RS-232C通信コンポーネントを CommX Ver1.06 に変更した。
   2. 受信イベントを生じないシリアルドライバに対応するため、イベントドリブンとセンシングを併用した。
   3. "Record only Fix data." の表示タイミングを修正した。

 Ver 1.11 Jan. 2009
   1. シリアルポート・オープン直後にフラッシュROM容量が表示されなかったのを修正した。

 Ver 1.10 Jan. 2009
   1. AGPS有効時間の表示を修正した。
   2. ７日以上の EPOデータの部分読み込み機能を追加した。
   3. EPOファイルのセーブ機能を追加した。
   4. Logダウンロード中は AGPS画面を開けないようにした。
   5. DGPSモード設定機能を追加した。
   6. タブオーダーを修正した。

 Ver 1.09 Dec. 2008
   1. ダウンロードエラー時にも終了せず次に進むようにした。
   2. ログ停止が出来なくても中断しないようにした。

 Ver 1.08 Dec. 2008
   1. 設定ファイルのコマンドライン指定およびドラッグ＆ドロップを可能にした。
   2. AGPS送信タイミングを修正した。
   3. センテンスモニタ表示に非テキストを表示しないようにした。
   4. ダイアログボックスの表示位置を修正した。

 Ver 1.07 Dec. 2008
   1. FTPサーバーにファイルが見つからない場合のエラー表示を修正した。

 Ver 1.06 Dec. 2008
   1. AGPS設定機能をサポートした。

 Ver 1.05 Nov. 2008
   1. Nmea data 表示で HDOPとVDOPが入れ替わっていたのを修正した。

 Ver 1.04 Oct. 2008
   1. NMEAおよびCSV出力の緯度経度の小数点以下の桁数を指定できるようにした。
   2. NMEAおよびCSV出力の標高と速度の小数点以下の桁数を設定ファイルで変更できるようにした。

 Ver 1.03 Aug. 2008
   1. レスキューモードを追加した。
   2. NMEA出力を追加した(Geoidオプションも追加)。
   3. データの代わりにNMEAが返った場合は早めに再送要求を出すようにした。

 Ver 1.02 Jul. 2008
   1. Qstarz BT-Q1300 に対応した。
   2. 受信打ち切りエラー回数を総計５回からセクター毎に5回までに変更した。
   3. ロケールが日本の場合はデフォルトのフォントをMS Pゴシックに変更した。
   4. ヒント表示を追加した。

 Ver1.01 May. 2008
   1. NMEA2KMZ.EXE が起動中ならファイル名をドロップするようにした。
   2.ダウンロード後にCSV出力オプションを変更可能にした。
   3. CSVファイル出力のオプションを追加した。
      1) INDEXを出力しない。
      2) TIMEに日付と時刻を出力する。

 Ver1.00  May. 2008
