﻿
                                 MtkDLut Ver3.36

                               Mar. 2025 (C)4river
                           http://4river.a.la9.jp/gps/

Summary.
  The log data is downloaded from GPS logger of
    Transystem: i-Blue747, i-Blue821, 747A+, 747ProS, photoMate 887
    Qstarz: BT-Q1000, BT-Q1000X, BT-Q1300, BT-Q1300ST
    HOLUX: M-241 plus, M-241, RCV-3000, M-1000C, GPSport 245(YUPITERU ASG-1)
  The output condition of the log and the NMEA sentence can be set.

  Operating condition.
    Operational OS: Window 11, Window 10, Window 8.


Feature.

  1) It downloads USB and Bluetooth(Model dependent) and the CSV file is made.
  2) Only the data when Fix it can be set to the record mode(Model dependent).
     Because it does not record the non fix data, Flash memory can be saved.
  3) It outputs to the single CSV file to which also the log of M-241 includes the POI.
  4) With Overwrite mode becoming in full memory, order of the record does not reverse.
  5) Calling NMEA2KMZ.exe, it can convert to KMZ and GPX etc.
  6) The user can add the judgment condition and the function of GPS.
  7) It is possible to download it automatically by a command line option.
  8) Because the installation is unnecessary, it is possible to execute it on USB memory.
     Note) When GPS is USB connection, the driver's installation is necessary.


Install.
  In installation just copies executable file MtkDLut.exe in the suitable folder.
  Because registry is not used, it can Un-install with only the deletion of MtkDLut.exe and MtkDLut.ini.
  To correct the geoid, it is necessary to acquire the geoid grid data separately and to copy
  it onto the same folder as MtkDLut.exe (Another folder can be specified with "DataPath" of the
  [NMEAoption] section of the configuration file).
  It is possible to use it by doing a necessary area from EGM2008 in the clip by using the "CustomGeoid" utility

  The acquisition of geoid grid data.
    EGM2008 2.5'x2.5':
      National Geospatial-Intelligence Agency (NGA)
      NGA: EGM2008 - WGS 84 Version
      http://earth-info.nga.mil/GandG/wgs84/gravitymod/egm2008/egm08_wgs84.html
      2.5 x 2.5-Minute Geoid Undulation Grid in WGS 84 - SMALL ENDIAN
      "Und_min2.5x2.5_egm2008_isw=82_WGS84_TideFree_SE.gz" is decompression and
      "Und_min2.5x2.5_egm2008_isw=82_WGS84_TideFree_SE" (149,368,328byte) is obtained.
    EGM2008 1'x1':
      National Geospatial-Intelligence Agency (NGA)
      NGA: EGM2008 - WGS 84 Version
      http://earth-info.nga.mil/GandG/wgs84/gravitymod/egm2008/egm08_wgs84.html
      1 x 1-Minute Geoid Undulation Grid in WGS 84 - SMALL ENDIAN
      "Und_min1x1_egm2008_isw=82_WGS84_TideFree_SE.gz" is decompression and
      "Und_min1x1_egm2008_isw=82_WGS84_TideFree_SE" (933,292,808) is obtained.
         Note)Because the difference with EGM2008 2.5'x2.5' is about less than 3.5mm,
              2.5'x2.5' is usually enough.
    GSIGEO 2011:
      CD-ROM of Geographical Survey Institute is obtained or it downloads it from the Web site.
      Geospatial Information Authority of Japan "Geoid 2011(Ver.2.2) in Japan" geoid model data
      http://www.gsi.go.jp/buturisokuchi/geoid_index.html
      https://fgd.gsi.go.jp/download/geoid.php
      zip file is decompression and "gsigeo2011_ver2_2.asc" (19,670,776byte) is obtained.
        Note) Download requires user's registration.


Usage.

 1. Serial Port connection
   In appointing "Com Port" and "Baud Rate" in "Serial Port" screen, it clicks "Open" button.
   When the "Close" button is clicked, the serial port is Close.
   When the port number is an unknown, an effective port is scanned when the "Scan" button
   is clicked, and the port is opened when GPS logger is found.

   Display option setting.
     NMEA:     The received NMEA sentence is displayed.
     MTK:      Displays the received MTK or HLX sentence.
     Log data: The head 80 characters of the received log data are displayed.
               When ">>" is displayed at the beginning, it indicates that the binary code is displayed in hexadecimal.
     Send Cmd: The command transmitted to GPS is displayed.

   GPS Command
    Click the "Factory" button sends a factory reset command to the GPS and displays the fix time.
    Click the "Cold" button sends a cold start command to GPS and displays the fix time.
    Click the "Warm" button to send a warm start command to GPS and display the fix time.
    Click the "Hot" button to send a hot start command to the GPS and display the fix time.


 2. Download of GPS log

   The download screen is opened clicking "Log Download".

   It is necessary to register to configuration file MtkDLut.ini because it is Flash ID of unregistration when displayed.
   Please correct the following "Configuration file" after ending MtkDLut.exe.

     Please) If "Unknown Flash ID" is displayed, please inform the author of the Flash ID, Flash capacity, and GPS model name.

   The download of the GPS log begins when the "Download" button is clicked.
   If the download fails due to a CheckSum Error, etc., check the "Rescue" checkbox and try again.
     Note1) It somewhat takes starting download time at the Bluetooth connection.
     Note2) Operation when "Rescue" check box is checked.
            1) Download all valid data, ignoring record size information and checksum errors. 
            2) Data immediately before can be saved when abnormally interrupting.
            When the mismatch is caused in data in the contingency like the power supply trouble etc. , it uses it.
            The "Rescue" mode is not saved in the configuration file.

   Download block size setting.
     The "Blocks" combo box allows you to specify the log size of MTK loggers to be read at one time (default is 64kb).
     If the log size is less than 64kb, you can reduce the download time by reducing the block size.
     If the block size is less than 64kb when the log size is greater than 64kb, the download time is longer.
     If a download error occurs, please try downloading in a small block size.
       Total log bytes = Record Count * Byte/Record
         Record Count : "Record Count:" in the "Logger Status" group box on the "Log Download" screen.
         Byte/Record  : "Bytes/Record" status at the bottom of the "Log setting" screen.

   The type of the output file is selected beforehand in "CSV" and the "NMEA" check box.
   Because the Save dialog opens when download is completed, the file name is input and the
   "OK" button is clicked (It is possible to preserve it with the "Save Log" button again).
   The extension name is unnecessary in the file name of the Save dialog (It is disregarded even if it specifies it).

   NMEA2KMZ.exe is called when the "KMZ/GPX" button is clicked and the file translation is done.
   If NMEA2KMZ.exe is in a different folder from MtkDLut.exe, the open dialog opens only for the first time,
   so specify the NMEA2KMZ.exe folder.
     NMEA2KMZ: http://4river.a.la9.jp/gps/#003

   If the "KMZ/GPX" checkbox is checked, NMEA2KMZ.exe is automatically invoked to perform file conversion when saving the log.
   If you check the "/Q" check box, NMEA2KMZ.exe will be closed after conversion.
     Note) If you clear the "/Q" check box, you can change the settings of NMEA2KMZ.exe and then reconvert with the "KMZ/GPX" button.

   Download is interrupted with the "Cancel" button.
   The waiting time of about 18 seconds or less is required until the download stream ends.

   Because download begins and GPS is set in the log stop condition, the "Start Log" button is
   clicked so that the log record may begin. 
     Note) A portion of GPS disregards the control of "Satrt Log" and "Stop Log".

   When the "Erase Log" button is clicked, all logs of GPS are deleted.

   Logger Status
     Status:       Display of Recording/Stopping of the log.
     Time:         Logging time interval.
     Distance:     Logging interval of the log due to the distance.
     Speed:        The minimum speed of the log by the speed.
     Method:       Stop/Overwrite memory when full.
     Record count: Number of records.
     Record point: Recording position (Hex).
     Version:      Version information.
     Flash ID:     Flash memory ID.
     Fail sector:  Fail sector information(Display hexadecimal fail pattern when you place the mouse cursor).
                   Note) A percent display is displayed by a table size ratio (it is not a real memory ratio).

   Option setting
    1)The output item can be specified in the "CSV option" group box.

     Index:      The data number is output.
     Date+Time:  The date and time are output to "TIME".
                 When unchecked, Date and Time will be output separately.
     N/S,E/W:    "N/S" and "E/W" in the latitude longitude are output by the individual item (Logger Tool compatible).
                 When the check is removed, it becomes easy to process by Excel etc.
                 because it outputs it by the addition of the sign of the positive and negative numerical value.
     With Units: Units such as "M" and "km/h" are output (Logger Tool compatible).
                 When the check is removed, it becomes easy to process by Excel etc.
                 because it outputs only the numerical value.
     Valid by value: The measurement is output by the numerical value.
                      0 : Invalid      1 : SPS fix
                      2 : DGPS fix     3 : PPS fix
                      4 : RTK fix      5 : FloatK fix
                      6 : Estimated    7 : Manual input
                      8 : Simulator
     Used,View:  The number of Used/View satellites is separated and it outputs it to two items.
     Separator:  The item of the data separation factor is added.
     Dec.:       The number of digits below the decimal point in the Latitude/Longitude
                 of the CSV output is specified (4 to 8 digit).

    2)The option of the NMEA output can be specified in the "NMEA option" group box.

     Lat/Lon:    The number of digits below the decimal point in the Latitude/Longitude
                 of the NMAE output is specified (4 to 8 digit).
     Alt/Geoid:  The number of digits below the decimal point in the Altitude and Geoid
                 of the NMAE output is specified (1 to 6 digit).
     Geoid model: The geoid model can be selected.
       Fixed value:       It corrects it by a fixed value regardless of the position.
       Custom Geoid:      It corrects it by using the geoid file that does the clip by the CustomGeoid utility.
       EGM2008 2.5'x2.5': It corrects it by using 2.5'X2.5' grid data of NGA.
       EGM2008 1'x1':     It corrects it by using 1.0'X1.0' grid data of NGA.
       GSIGEO 2011 Ver2:  It corrects it by using 1.0'X1.5' grid data of Geographical Survey Institute.
                          When it selects first time, it takes time to convert it into the binary data.
       GSIGEO 2011 Ver1:  It corrects it by using 1.0'X1.5' grid data of Geographical Survey Institute.
                          When it selects first time, it takes time to convert it into the binary data.

     Note) The CSV and NMEA file can be output again by changing the option setting.


 3. Log condition setting

    Setting screen is opened clicking "Log setting".
    When a target check box is checked and the "SET" button is clicked, the setting of GPS is updated.

    When "Fix only" of "Recording mode" is checked, only the Fix data is recorded.
    Note) It is effective since firmware "B-core".
          For "BT-Q1300" etc, only positioning data is recorded regardless of this setting.

    When the "Default" button is clicked, only the item of default is checked.
    When the "Clear all" button is clicked, all items are cleared.
    When the "Select all" button is clicked, all items are checked.
    The GPS setting is not updated until the "SET" button is clicked.

    A "Method" of "RCR"(Record reason) is necessary to record an interest point.
    When "Fix Only" of "Recording mode" is turned off, it is necessary to check "Valid" of "Fix mode" to identify non-Fix state.

    A present setting is read from GPS when the "Refresh" button is clicked and the display is updated.

    Note 1) It can set log time interval to 0.1 seconds, but it is not something which guarantees the operation in 1 seconds less than.
    Note 2) When "Date Time" it is not included in log output, with setting of the time interval "by Time" becomes illegitimate.
    Note 3) At each time it is start/stop of log and Change of Log condition because 32Byte is consumed,
            as for indication of the maximum of records is only as a guide.
    Note 4) When the output item of HOLUX M-241 is changed, it is not possible to download it with HOLUX Logger utility.
            In this case, please return to the default item setting.
    Note 5) When with HOLUX M-241 with log time interval as 1 seconds less than,
            the button operation of GPS is done, NMEA output interval returns to 1 seconds.
    Note 6) When the output item of BT-Q1300 is changed, it is not possible to download it
            normally by "Travel Recorder PC Utility V4". 
            In this case, please return it to the setting of default item.
    Note 7) Even if "by Time" of "Auto Log" is set, i-Blue747ProS disregards it.
    Note 8) Log conditions can not be changed with "M-241 Plus", "RCV-3000", etc


 4. NMEA output setting

    The NMEA output setting screen is opened clicking "NMEA setting".

    NMEA setting
      When the frequency of the sentence that wants to output is set and the "SET" button is
      clicked, the setting of GPS is updated.
      When a "Default" button is clicked, setting of default is indicated,
      so when a "SET" button is clicked, setting of a GPS is set as default.

    DGPS source
      No DGPS : DGPS is not used.
      RTCM    : DGPS by RTCM-SC104 is used.
      SBAS    : SBAS(Satellite-Based AugmentationSystem) is used.

    DGPS mode
      Disable : DGPS mode is disable.
      Enable  : DGPS mode is enable.

    Baud change
      The baud rate of a NMEA port can be changed.
      Click a right side drops down button, and it chooses a baud rate.

    The setting of present GPS is read when the "Refresh" button is clicked and the display is updated.

    Though the cycle of the sentence can be set by the unit of millisecond in the "Period"
    column, It is assumed 1000mS usually.

    Note) Operation cannot be guaranteed although an output cycle can be set up to 100mS.
          The setting is disregarded according to GPS or there is a possibility of hang-up.

    Click the "Update RTC" button to set the GPS RTC timer to the current time.
    This is used when the date becomes invalid due to EOW rollover.
      Note 1) The GPS time advances several seconds until the leap second correction is completed (up to 12 minutes after the fix).
      Note 2) Re-setting may be required due to battery depletion.
      Note 3) Older chipset takes tens of seconds to update.
      Note 4) If [RTCfix] in the [Option] section of the configuration file is "1", it is automatically executed when necessary.


 5. AGPS setting function

    Because an "AGPS setting" button is displayed when GPS supports AGPS function, click it and open a AGPS setting screen.
    AGPS data files can be obtained from HTTP or FTP servers or local PC files.
    Get AGPS data when click an "Update" button and transmit a message to GPS receiver.
    Display current AGPS expiration date when click a "Query" button.
    Clear the AGPS information of the GPS receiver when click a "Reset" button.
    When "Save" is checked, the EPO data is saved as a file (The same folder saving ahead as "File name" of "Local File").
    When MTK14.EPO including the data the 14th is preserved, AGPS is made effective for about 14 days with PC of off-line.
    When the EPO file is dragged, the file name is set in "File name" of "AGPS File".
     Note1) Even if "Auto setting" of Proxy server is checked, correct information might not be obtained.
            In this case, please turn off the check and set the manual operation.
     Note2) A long time is required the data transfer in the Bluetooth connection.
            Please execute it by USB connection as much as possible.
     Note3) Specify HTTP server URL with EPO file name.
              Example) https://xxxxx.com/EPO/MTK7d.EPO


 6. Termination

    "Exit" is clicked.


 7. The command line option.

    /A /D /G /Q in addition to the configuration file can be used.

     /A The log is automatically downloaded.
        The log file name is made at the start time of data.
        The format can be specified in the [FileName] section of the configuration file.
        The save folder can be specified with "SaveFolder" of the [Option] section of the configuration file.
     /D After the log is saved, the log data of GPS is deleted (non-recommendation).
          CAUTION) The log data might be lost by the accident.
     /G The AGPS data is downloaded and updated.
     /Q It ends automatically.
    
     Ex) MtkDLut.exe /A /Q
         MtkDLut.exe Test.ini /A /Q

     Hint) A command line option can also be applied to a shortcut of an executable file.
           A shortcut is right-clicked and a "Property" is chosen, and a command line option
           is added to tail end of the "Target".
           It is convenient to make two or more short cuts according to the purpose.


Addition item of output CSV file

   "SEPARATOR" field.
    The separation factor of data is shown by combining single character.
      L : Logger Start/Stop.
      F : Format Register.
      T : Auto Log by Second.
      D : Auto Log by Distance.
      S : Auto Log By Speed.
      M : Recording Method Overwrite/Stop.


Configuration file "MtkDLut.ini"

    The options setting when ending is preserved in MtkDLut.ini of the same to execution file folder.

    If the folder that contains the executable file(MtkDLut.exe) is write-protected,
    the configuration file will be copied and used in the following folder.
      C:\Users\[User name]\AppData\Local\VirtualStore\[MtkDLut folder]\MtkDLut.ini

        [User name] is the folder that appears when you type "echo %APPDATA%"<Enter> at the DOS prompt.
        [MtkDLut folder] is the folder there is a MtkDLut.exe.

    Two or more configuration files are preserved and it is possible to select it with
    the command line or the drug & drop.
    The drag during serial port opening is prohibited.

  1. [Flash ID] Section
     The log capacity of GPS logger and the correspondence of Flash ID are registered.
     It is possible to register from 1MByte to 16MByte.
     Two or more Flash ID can be registered by delimiting it as follows by comma(,).
       8MB=xxxxxxx,yyyyyy,zzzzzz
     Flash ID of 2MByte and 4MByte has registered.

  2. [Font] Section
     The font name and the size can be specified.
     Please note excess to the display area according to the font and the size.

  3. [Option] Section
     NMEA2KMZop :   The option parameter passed to NMEA2KMZ.exe can be set ("/Q" is no effect).
                    The specification of the configuration file (.ini) can be added.
                    If the configuration file is not in the same folder as NMEA2KMZ.exe, describe with the full path.
                      Note) When NMEA2KMZ.exe is running, only the configuration file (.ini) is valid.
     MaxSNR :       The maximum scale in the SNR bar chart is specified.
     MemoMaxLine:   The maximum number of lines of the NMAE sentence display are specified.
     LogDateOffset: Date offset of log data   (default value is 25569 =1970years).
                    Note) For binary log format GPS, it can be set for each GPS model in the [GPS_Data] section.
     EOWfix:        Specify whether to enable/disable EOW countermeasures for recorded log data.
                      1 = Perform EOW measures (default).
                      0 = Do not take measures.
                      Summary of the processing :
                         While (Now - LogTime) > 1024*7 Do LogTime := LogTime + 1024*7
     RTCfix:        Specify whether to enable/disable GPS RTC timer automatic correction.
                      1 = Perform automatic correction (default).
                            Note) If the battery is exhausted even after correction, it will return to the original state.
                      0 = Do not modify.
     TimeVerification: Enable/Disable of the log time check is specified.
                         1 = The check is enable (default).
                         0 = Not check.
              Note) In the case of options TimeVerification = 1,
                    if the date and time is of the following it will discard the data.
                      1) Time before February 22, 1978 ( January 1, 2000 in case of Holux GPS ).
                      2) It has progressed more than one hour from the current time.
     SkipOneTrack:  If set to 1 for "M - 241 Plus" or "RCV - 3000",
                    the track selection screen will not be displayed if the Track number is 1.
     MaxBaud:       Maximum baud rate for serial port scan.


  4. [CSVoption] Section
     AltitudeDecimal : The number of digits under the decimal point in the Altitude of the
                       CSV output is specified(1 to 8 digits).
     SpeedDecimal:     The number of digits under the decimal point in the Speed of the
                       CSV output is specified(1 to 8 digits).
     WithGPSname:      The GPS name is output to INDEX of the CSV file at "1".
                       If it is "0", the GPS name is not output.

  5. [NMEAoption] Section
     WPL_Prefix:      The point name prefix of the WPL sentence of NMEA to POI.
     LatLonDecimal:   The number of digits under the decimal point in the Latitude/Longitude
                      of the NMEA output is specified(1 to 8 digits).
     AltitudeDecimal: The number of digits under the decimal point in the Altitude of the
                      NMEA output is specified(1 to 8 digits).
     SpeedDecimal:    The number of digits under the decimal point in the Speed of the
                      CSV output is specified(1 to 8 digits).
     GeoidModel:      Geoid model who has been selected.
     DataPath:        Path with the geoid grid data is specified.
                      It is considered the same to execution file folder in case of emptily.
     Geoid:           Fixed geoid value (m).

  6. [GPS_Data] Section
     The correspondences of Release Note and the GPS name, etc. can be specified.

     Format
       GPS_ID = GPS_Name, Def_BitMask, ShortLog, Logging_Mode, Logging_Start/Stop, EPO_rec, KeepAwake_Command, Altitude mode

     Content
       GPS_ID
         For binary log format GPS:
           Use an answer to "$PHLX810*35" command.
             Ex) If the answer is "$PHLX852,M241Plus*5F", it is "M241Plus".
           When describing it for each firmware, append the answer version of the $PHLX829 command at the end, separated by "/".
             Ex) If the answer to the "$PHLX829*3F" command is "$PHLX861,104*2A", it is "M241Plus/104".

         For text log format GPS:
           The fourth(or third) parameter of Release Note ($PMTK705).
           Exception when it doesn't contain the third parameter.
             M-core  : When the first parameter starts by "M-core", it applies.
             B-core  : When the first parameter starts by "B-core", it applies.
             Unknown : When not corresponding to the above.

       GPS_Name
         GPS name for display.

       Def_BitMask
         Bit mask for setting of record item of default (Hex).
         A present value is displayed under the "Log setting" screen.
           Bit31: Only the Fix data is recorded.
           Bit19: Distance.
           Bit18: millisecond.
           Bit17: RCR (Record Reason).
           Bit16: SNR (necessary SID).
           Bit15: Azimuth (necessary SID).
           Bit14: Elevation (necessary SID).
           Bit13: SID (Satellite ID).
           Bit12: Number of use satellites.
           Bit11: VDOP.
           Bit10: HDOP.
           Bit9 : PDOP.
           Bit8 : DGPS age.
           Bit7 : DGPS station.
           Bit6 : Heading.
           Bit5 : Speed.
           Bit4 : Height.
           Bit3 : Longitude.
           Bit2 : Latitude.
           Bit1 : Valid.
           Bit0 : UTC.
         Note) When the log data is in binary mode ("M-241 Plus" etc), specify the bit mask (hexadecimal) of POI for Flag.

       ShortLog
         0: Standard:   Lat./Long. 8byte Double, Speed 4byte Single,  Height 4byte Single.
         1: M-241:      Lat./Long. 4byte Single, Height 3byte Single.
                        The separator and the way point are 32 bytes.
         2: M-1000C:    Lat./Long. 4byte Single, Speed 4byte Integer(cm/Sec), Height 3byte Single.
                        Sequence of Altitude and Speed is reverse.
                        The separator and the way point are 32 bytes.
         3: M-241 Firmware Ver1.13:
                        Lat./Long. 4byte Single, Height 3byte Single, Speed 4byte Single.
                        The separator and the way point are 40 bytes.
         4: GPSport 245:
                        Lat./Long. 4byte Single, Speed  3byte Integer(256*cm/Sec), Height 4byte Single.
                        The separator and the way point are 40 bytes.
                        Sequence of Altitude and Speed is reverse.
         5: M-1000C Firmware Ver1.03:
                        Lat./Long. 4byte Single, Speed 4byte Integer(cm/Sec), Height 3byte Single.
                        Sequence of Altitude and Speed is reverse.
                        The separator and the way point are 40 bytes.
         6: 747ProS:    The same data format as Standard.
                        Two kinds of condition settings of "Smart mode" and "Car mode".

         7: Binary mode: Right shift CRC (using Left shift table)  Illegal (M-241 Plus, RCV-3000)
         8: Binary mode: Left shift CRC  (using Left shift table)  Standard CRC32
         9: Binary mode: Right shift CRC (using Right shift table) Standard CRC32
        10: Binary mode: Left shift CRC  (using Right shift table) Illegal
             CRC Polynominal : X^32+X^26+X^23+X^22+X^16+X^12+X^11+X^10+X^8+X^7+X^5+X^4+X^2+X^1+1
             Initial value   : 0xFFFFFFFF

       Logging_Mode
         0: Fix + NonFix.
         1: Fix Only.
         2: Programmable.

       Logging_Start/Stop
         0: Not supported.
         1: Supported.
         2: Limited.

       EPO_rec
         Record capacity of AGPS information (4Rec/Day).
         Default is 28 (Seven days).

       KeepAwake_Command
         Sleep prevention command（It encloses it with double quotes).

       Altitude mode
         0: Above WGS-84 ellipsoid.
         1: Mean sea level altitude.
            "(MSL Alt)" is displayed at the right of the GPS name,
            and the Geoide height is not subtracted.

     EX) 01017-00E=M-241,8000001D,1,2,1,,"$HOLUX241,6",1
         TSI_887=photoMate887,0002003F,0,1,0,28,

     Additional information for Binary mode.
       The user can specify the data composition and index configuration.
        |<data position>|<data format>|<data divisor>|<data addition>|<index position>|<index format>|<index divisor>|<index addition>|<record size>

       <data position> : Specify the start position of the Logging data.
                          Data order: Date time, Latitude, Longitude, Altitude, Speed, Flag
                                      Items without data should be blank or zero.
                                        Ex.) |1,5,9,13,15,18|

                          The user can add items to the last (up to 4 items: Aux1 to Aux4).
                              Ex.) |1,5,9,13,15,18,19,21,23,25|
                            You can specify the name by separating it with a colon (:) immediately after the number.
                            When name is not specified, "Aux1" to "Aux4" are allocated.
                              Ex.) |1,5,9,13,15,18,19:Heartrate,21:Altimeter,23:Heading,25:Distance|
                            If you add a period and a numeric value of one digit (.0 to .9) to a number,
                            you can specify the number of digits after the decimal point (If omitted, it is 0 digit).
                              Ex.) |1,5,9,13,15,18,19:Heartrate,21.1:Altimeter,23.1:Heading,25.3:Distance|

                            Note1) Items added are only output to the CSV file.
                            Note2) Specifying the "item name" and the "number of decimal places" is valid only for additional items.
                            Note3) Items that can be added are numeric only.

       <data format>   : Specify the format of the original data (the last number is in bytes).
                          S4,S3,S2,S1: Signed integer.
                          U4,U3,U2,U1: Unsigned integer.
                          F8,F4,F3:    Floating point (F3 omitted from the lower 1 byte of F4).
       <data divisor.> : Value to divide data.
       <data addition> : Value added to data.

       <index position>: Specify the start position of the Index data.
                          Data order: Start Time, Time Length, Record point, Record count
       <index format>  : Specify the format of the original data (the last number is in bytes).
                          S4,S3,S2,S1: Signed integer.
                          U4,U3,U2,S1: Unsigned integer.
                          F8,F4,F3:    Floating point (F3 omitted from the lower 1 byte of F4).
       <index divisor> : Value to divide data.
       <index addition>: Value added to data.

       <record size>   : Number of data bytes per record, Maximum number of records of data 1 block,
                         Number of index bytes per record, Maximum number of records in index 1 block, Maximum log capacity
                           Default value) 64,32,32,64,253952

       Example) M241Plus=M-241 Plus,10,7,1,,,,0|1,5,9,13,15,18|U4,F4,F4,S2,U2,U1|86400,,,,10,|36526,,,,,|17,21,29,33|U4,U4,U4,U4|86400,,,|36526,,,
                  The time is calculated as   T = t / 86400 + 36526
                  The speed is calculated as  S = s / 10

       Hex dump function.
         When "x" or "X" is added to the end of the <data position> of Aux1 to Aux4, the value is displayed in hexadecimal (Integer: for U1-U4, S1-S3 only).
         "x" : Little endian (displayed according to signal reception sequence).
         "X" : Big endian.
            Example) Dump from 1st to 16th bytes.
              M241Plus=Dump 01-16,10,7,1,,,,0|1,5,9,13,15,18,1x,5x,9x,13x|U4,F4,F4,S2,U2,U1,U4,U4,U4,U4|86400,,,,10,|36526,,,,,|17,21,29,33|U4,U4,U4,U4|86400,,,|36526,,,
            Example) Dump from 17th to 32nd bytes.
              M241Plus=Dump 17-32,10,7,1,,,,0|1,5,9,13,15,18,17x,21x,25x,29x|U4,F4,F4,S2,U2,U1,U4,U4,U4,U4|86400,,,,10,|36526,,,,,|17,21,29,33|U4,U4,U4,U4|86400,,,|36526,,,

       Process in case of unregistered logger.
         If there is a response in the Track-number-inquiry-command ($PHLX701), it is regarded as a binary transfer logger
         "DefaultBin=Unknown GPS (Binary mode), ..." setting is applied.

  7. [EGM2008_25],[EGM2008_10] section.
     title: Title name of geoid model.
     fname: File name of geoid model.
     nrows: Number of input data of directions of Y.
     ncols: Number of input data of directions of X.
     glamn: Latitude in the south end.
     glomn: Westernmost longitude.
     dgla:  Data step of latitude (degree).
     dglo:  Data step in longitude (degree).
     nlat:  Number of effective data of directions of latitude.
     nlon:  Number of effective data of directions of longitude.
     PrePad: Number of invalid data of longitude heads.

  8. [GSI] section.
     title: Title name (Multiple descriptions are possible by separating with semicolon).
     fname: File name  (Multiple descriptions are possible by separating with semicolon).
     nrows: Number of input data of directions of Y.
     ncols: Number of input data of directions of X.
     glamn: Latitude in the south end.
     glomn: Westernmost longitude.
     dgla:  Data step of latitude (degree).
     dglo:  Data step in longitude (degree).
     nlat:  Number of effective data of directions of latitude.
     nlon:  Number of effective data of directions of longitude.
     PrePad: Number of invalid data of longitude heads.
     Spline: The spline interpolation is used by one.

  9. [FileName] section.
     The Save file name when downloading it automatically is specified.
     To insert an arbitrary character string, it encloses it with "<" and ">".

     UTC_Time:     UTC by 1, Local time by 0.
     Time_fortmat: The format at time of the date is specified.
                   The following, special character is effective.
                   y: Year, m: Month, d: Day, h: Hour, n: miNute, s: Second
                     Ex) yyyy-mm-dd_hh-nn-ss
                         mm-dd-yyyy_hh-nn-ss
                         yyyymmdd_hhnnss
                         <GPS1_>yyyymmdd_hhnnss
                         <FixdName>

Restrictions on M-241 Plus Ver1.04 and RCV-3000 Ver1.02
  1. Can not download via Bluetooth.
  2. Log setting.
     Only "Recording method", "Auto Log" can be set.
  3. NMEA setting.
     Only "Period(mS)", "DGPS source", "DGPS mode", "Baud change" can be set.
       Note) Changing the baud rate to 115200bps halves the download time,
             but it will become unstable without speeding up even if it is more than that.
             In this case, exit with "Exit" button and execute "Scan" of RS-232C after restart.
       Warning) When using "HOLUX ezTour for Logger" please return the baud rate to 38400bps.


MTK GPS logger specifications table
  http://4river.a.la9.jp/gps/gps_spec.htm


Troubleshooting

  1. The serial port cannot be connected.
     Please reconnect the USB cable detaching it.
     Because GPS becomes the sleep mode by time-out at the USB connection, please put it 
     into the log recording mode (Especially, old type such as i-Blue747, BT-Q1000 etc.).
     There is a necessity for correctly setting the Baud rate for USB connection.

  2. The CSV output value of Logger Tool V2.5 are different.
     There might be the difference of +-1 in the least significant digit values because of the rounding error margin.
     0 of the first under decimal point of PDOP, VDOP, and HDOP digits is correctly output.
     The specification of the zero suppression of a negative value might be different.
     80 years of the RMC sentence are output as 1980 no 2080 it.

  3. The downloaded number of records is less than that of "Record Count".
     Invalid data and the error might be included in the data of GPS logger (compulsive cutting of a power supply etc.).

  4. Cannot download via Bluetooth.
     i-Blue747, BT-Q1000, M-241 Plus, RCV-3000 cannot download it by Bluetooth.

  5. Cannot download via USB.
     It is necessary to set the baud rate correctly.
     Please make the mode of GPS "LOG" mode and try.

  6. The number of satellites of GSA sentences of the NMEA output is actually different.
     The satellite of non-use might be omitted to the logger output.

  7. Download fails due to CheckSum Error etc.
     Please check the "Rescue" checkbox before downloading.
       Note) Data integrity is not guaranteed.
     This may be improved by reducing the download block size "Blocks".


In compiler used
  Embarcadero Delphi 12.1 Community Edition.

  In addition free component used
    CommX Ver1.06 X(KYY06770) person work. RS232C communication component COMMX106.LZH
    In the writer who the very useful component was offered we appreciate.


Release note.
  * This application is the free software.
  * This application is redistributable, but please distribute it including an execute file and a document.
  * The author takes no responsibility to any losses and obstacles which were produced by use or distribution of this application.


Version history.

 Ver3.36
   1. Fixed a bug when changing "Date and time formats" in Windows.

 Ver3.35
   1. Japanese geoid model "GSIGEO 2011 ver2.2" was added to the menu (The geoid of Iwo Jima has been added).

 Ver3.34
   1. Abnormal termination countermeasures for FEP ON/OFF have been abolished.

 Ver3.33
   1. Japanese geoid model "GSIGEO 2011 ver2.1" was added to the menu.

 Ver3.32
   1. Prevented the abnormal termination by FEP ON/OFF on Windows 11 version 22H2 Japanese version.

 Ver3.31
   1. The SSL library (ssleay32.dll and libeay32.dll) for HTPPS access is no longer needed.

 Ver3.30
    1. Enabled to specify the read size of MTK logger at each time.
    2. In rescue mode, data with missing log data header is also read.

 Ver3.29
    1. Enhanced reading of rescue mode for MTK logger.
       If there was a checksum error in each record, the application will advance the point one character at a time and repeat the procedure.
    2. Fixed a bug that excessively updates the RTC timer when downloading logs.

 Ver3.28
   1. The checksum error is now ignored in the rescue mode.
   2. The hint message was reviewed and corrected.

 Ver3.27
   1. When there is no GPS signal, the GPS RTC timer is set to the current time after downloading logs with incorrect time.

 Ver3.26
   1. Enabled automatic correction of EOW rollover of GPS time (Return to the original due to battery exhaustion).

 Ver3.25
   1. Fixed a bug that AGPS data could not be downloaded with unregistered loggers.

 Ver3.24
   1. Added RTC timer update function (measures for EOW rollover).
      "NMEA setting" -> "Update RTC"

 Ver3.23
   1. EPO file is available for download from HTTP host.

 Ver3.22
   1. Fixed the bug that the file name passed to started NMEA2KMZ.exe is garbled.
   2. Added a check box to automatically start NMEA2KMZ.exe.
   3. Added check box to automatically end NMEA2KMZ.
   4. Changed the caption of "KML/KMZ" button to "KMZ/GPX".

 Ver3.21
   1. The Open/Save dialog is displayed in the center of the main form.

 Ver3.20
   1. Supported multiple displays.

 Ver3.19
   1. Implemented countermeasures for display with a high DPI display.
      By rewriting the manifest with ChangeMani.exe, it becomes possible to display reduced images with a high DPI display.
      http://4river.a.la9.jp/gps/file/ChangeManij.htm
   2. The compiler was changed to Delphi 10.3 Starter.

 Ver3.18
   1. Improved serial port scan.
      In the case of no detection at the initial baud rate, rescan was performed from high speed to low speed.
      The maximum baud rate can be specified by "MaxBaud" in the [Option] section of the configuration file (default is 115200bps).
   2. Increased the number of DropDownCount in the baud rate pulldown menu.

 Ver3.17
   1. Fixed a bug that LCD display is not updated when switching log mode (Overwrite/Stop) of Holux "M-241 Plus".

 Ver3.16
   1. Improved capability for binary format loggers.
      Speed uped downloading (eliminate unnecessary wait in loop).
      Fixed a bug that the last elapsed time does not display more than 60 minutes.

 Ver3.15
   1. Extended description for binary format logger in [GPS_Data] section of setting file.
      "Product Name" can be used for "GPS_ID".
      It was made possible to describe by firmware version.
      Added hexadecimal dump function to Aux1 to Aux4.
   2. The height of "Track Select" form was made changeable by mouse drag.

 Ver3.14
   1. Supported Holux RCV-3000.
   2. Supported Holux Holux M-241 Plus Ver1.04.
   3. The log capacity of binary log format GPS was made to be definable in the setting file for each model.
   4. The CRC mode of binary log format GPS can be specified in the setting file.
   5. The download time and the remaining time can be displayed for more than 60 minutes.

 Ver3.13
   1. Fixed a bug in CRC error handling when downloading from "M-241 Plus".
   2. The specification of the binary log format can be specified in the setting file.
      Users can flexibly handle variations in log format and data format.
   3. In the case of binary log format, up to four user defined items can be added.

 Ver3.12
   1. M-241 Plus F/W Ver1.03 was supported.
   2. Added progress indication on task bar when downloading M-241 Plus.

Ver3.11
   1. Improved support for "M-241 Plus".
      The remaining-time is displayed when downloading.
      Added track number display during downloading.
      When the latitude is other than ±90 degrees or longitude is other than ±180 degrees, the data is ignored.

Ver3.10
   1. Improved support for "M-241 Plus".
      Percentage display added to the display of the number of log points.
      Fixed a bug that caused deadlock when erasing logs.

Ver3.09
   1. Supported Holux M - 241 Plus.
      If the value of "SkipOneTrack" in the [Option] section is set to 1,
      the track selection screen is not displayed if the track number is 1.
   2. The log file is forcibly overwritten when /A and /Q command line options are used.

Ver3.08
   1. Exclude busy ports from the serial port list (do not check Bluetooth as response decreases).

Ver3.07
   1. The integer part of the latitude and longitude of the NMEA output sentence was changed to the fixed number of digits.

Ver3.06
   1. Fixed enbug that "KML/KMZ" button is disabled (Ver3.04 and Ver3.05).

Ver3.05
   1. Fixed a bug where the date display becomes illegal by region.
   2. Fixed "1C30151C" of "FlashID 2MB" to "1C20151C".

Ver3.04
   1. "1C30151C" was added to "FlashID2MB".

Ver3.03
   1. Added progress display to taskbar icon (Windows 7 and later).
   2. The compiler was changed to Delphi 10.2 Starter.

Ver3.02
   1. Supported HOLUX GR - 241 (M - 241 Japanese / English).
      Added the following to the [GPS_Data] section of the configuration file.
        GR241=GR-241(M-241 Jpn/Eng),8000003D,3,2,1,,"$HOLUX241,6",1

Ver3.01
   1. GSIGEO 2011 Ver2 were supported.
   2. The geoid model name in the geoid model selection pull down list can be specified in the setting file.

Ver3.00
   1. A measure of a EOW problem was performed.
   2. The character code of the configuration file was changed to Unicode (Does not change existing settings file). 
   3. The compiler was changed to Delphi 10.1 Berlin.

Ver2.07
   1. Displays the "FriendlyName" by serial port selection.

Ver2.06
   1. The option that specified "Enable/Disable" of the log time check was added (TimeVerification).
   2. Manual retouch.

Ver2.05
   1. The port that did not exist in the port scan was not scanned.
   2. 230400bps and 460800bps were added to the baud rate.
   3. "LogDateOffset" was added to the [Option] section of the configuration file.

Ver2.04
   1. The bug to which Waypoint of the HOLUX logger was not recognized was corrected.
   2. 230400bps and 460800bps were added to the baud rate.

Ver2.03
   1. It re-synchronizes if there is "Dynamic setting pattern" near the occurrence of the checksum error.
   2. It dealt with the lack of "Dynamic setting pattern" first part of the logger made by the HOLUX.

Ver2.02
   1. The reject of data by consecutive "FF" was limited to M-241.
   2. Even if "Serial Port" panel was opened while downloading it, download was not interrupted.

Ver2.01
   1. SaveDialog was changed into the old type in order to prevent a hang-up.

 Ver2.00
   1. Download processing of HOLUX M-241 has been improved.
      Processing in case "FF" continues in communication data was corrected.
   2. It was made to ignore when data had an internal error (not interrupted).

 Ver1.45
   1. When there was Fail Sector, the bug to which the number of records is restricted was corrected.
   2. Percent display of Fail Sector was added.

 Ver1.44
   1. Clear measures of "Log memory-full" were strengthened.

 Ver1.43
   1. The bug which cannot erase a log was corrected (Log is full-memory and "Recording Method" is "Stop").

 Ver1.42
   1. "Geoid 2011 (Ver.1) in Japan" (gsigeo2011_ver1.asc) was supported.
   2. The Galileo sentence was supported.

 Ver1.41
   1. When "NMEA setting" panel was selected, the content of the display was updated.

 Ver1.40
   1. The BDS(BeiDou Navigation Satellite System) sentence was supported.

 Ver1.39
   1. Changed the default of GSIGEO 2000 to "Japanese geoid 2,011+2,000" (gsigeo20112000.asc).

 Ver1.38
   1. When DPI on the display was changed, the layout was maintained (The adjustment of the fontsize is necessary).

 Ver1.37
   1. The command sending timing was corrected.
   2. The zero of SNR were changed blank for the GPGSV sentence of the NMEA output.

 Ver1.36 May. 2013
   1. Log deletion timing was changed after log item change.
   2. When PDOP or VDOP was contained in a log, the GPGSA sentence was added to the NMEA output.

 Ver1.35 Feb. 2013
   1. The baud rate was also searched by port scan.
   2. The number of visible satellite bar graphs was made variable.
   3. The Factory reset button was added.
   4. BT-Q1300ST was supported.

 Ver1.34 Dec. 2012
   1. The bug that skips the log condition setting after the log data is deleted is corrected
      (When there is not a log count after the deletion in zero).
   2. The log condition acquisition timing has been adjusted.

 Ver1.33 Dec. 2012
   1. The bug of the Auto Log check box display of 747ProS was corrected.

 Ver1.32 Dec. 2012
   1. 747ProS was supported.
   2. It supported "GPS_ID = 01029-00E" of M-241.
   3. The Versin display of Logger Status is corrected (Hex->Dec).

 Ver1.31 Aug. 2012
   1. Bug Fix of the AGPS transmission to Hanwha Pocket GPS S1 (PG-S1) (Log stop, GPS information non-indication).
      If it is a model which does not have the third parameter(model name) in $PMTK705 sentence,
      the baud rate of a "Change UART Format Packet" command shall be 0 bps.

 Ver1.30 Feb. 2012
   1. The NMAE baud rate of GPS was able to be changed.
   2. When the serial port was opened, it switched to the NMEA mode automatically if it was a binary mode.
   3. The baud rate was included in "Change UART Format Packet" command.

 Ver1.29 Nov. 2011
  1. It supported Holux M-1000C firmware Ver1.04 .
  2. When the log was cleared, the progress bar display etc. were initialized.
  3. The AGPS status was cleared by the serial port opening.

 Ver1.28 Apr. 2011
   1. It supported Transystem i-Blue747ProS.
   2. It corresponded to "Geoid 2000 in Japan Ver.5" of Geographical Survey Institute.

 Ver1.27 Jun. 2010
   1. The AGPS sending timing margin has been increased.

 Ver1.26 Jun. 2010
   1. It corresponded to AGPS of Hanwha Pocket GPS S1 (PG-S1).
      It is valid for 14 days maximum.

 Ver1.25 May. 2010
   1. When the NMEA setting was made "Default", the period was set to one second.
   2. NMEA period 100mS(10Hz) that can be set up.
   3. The limitation of the NMEA output item was abolished.
   4. The logger detection at the port scan was invalidated.
   5. It corresponded to the HOLUX M-1000C Ver1.03 2010-04-13 edition.

 Ver1.24 Feb. 2010
   1. The bug for M-1000C Firmware Ver1.03 was corrected.

 Ver1.23 Dec. 2009
   1. It corresponded to M-1000C firmware Ver1.03.
   2. The size of the Custom geoid file was checked.

 Ver1.22 Dec. 2009
   1. It corresponded to the Custom geoid file.
   2. The maximum lines of the NMEA sentence were able to be specified by the configuration file.

 Ver 1.21 Nov. 2009
   1. Division was enabled two items "Used/View" of the CSV output.

 Ver 1.20 Nov. 2009
   1. It supported Holux GPSport 245 (YUPITERU ASG-1).
      It implemented it by a user report and collaboration.
   2. The calculation of the amount of memory of the Holux logger was corrected.

 Ver 1.19 Nov. 2009
   1. Validated "/D" command-line option without "/A".
   2. The insertion of an arbitrary character string was enabled the automatic generation file name.
   3. Changed the initial setting of the log file name to local time.

 Ver 1.18 Oct. 2009
   1. A command line option for the automation was added.
   2. The method of selecting the output file type was changed.
   3. It corresponded to FlashID of new firmware photoMate887.

 Ver 1.17 Sep. 2009
   1. It supported Holux M-241 firmware Ver1.13.

 Ver 1.16 Sep. 2009
   1. The transmission timing margin of the EPO file was enlarged.
   2. It corresponds to the geoid model data of Geographical Survey Institute and
      National Geospatial-Intelligence Agency (NGA). 
      The geoid of the NMEA data was output corresponding to the latitude longitude.

 Ver 1.15 Jul. 2009
   1. PhotoMate 887 and M-1000C were supported.
   2. When the port was PROXY automatic setting and was 80 and 8080, it converted it into 21.
   3. The display of UsedSat, Altitude and Geoid was added.
   4. When the serial port was closed, it did not move to other screens.
   5. When it was not a logger, neither download nor the log setting screen were opened.

 Ver 1.14 Feb. 2009
   1.The bug to which M-241 Firmware V1.11 was not supported was corrected.

 Ver 1.13 Feb. 2009
   1. Information on the GPS name etc. was made to be able to be specified by the 
      configuration file (The user can add it).
   2. The display of the BitMask value was added.
   3. The function of the "Default" button of the "NMEA setting" was changed.
   4. The GPS name was output to INDEX of the CSV file.

 Ver 1.12 Jan. 2009
   1. The RS-232C communication component was changed to CommX Ver1.06.
   2. To deal with the serial driver who did not generate the receive event, event-driven and
      sensing were used together.
   3. The display timing of "Record only Fix data." was corrected.

 Ver 1.11 Jan. 2009
   1. It was corrected that the flash ROM capacity wasn't indicated just after the serial 
      port opening.

 Ver 1.10 Jan. 2009
   1. The display of AGPS effective time was corrected.
   2. The partial reading function of the EPO data of seven days or more was added.
   3. The saving function of the EPO file was added.
   4. The AGPS screen opening was prohibited while downloading Log.
   5. The DGPS mode setting function was added.
   6. The tab order was corrected.

 Ver 1.09 Dec. 2008
   1. It was made to advance as follows without abort even when the download error occurred.
   2. It was made not to abort even if the log was not able to stop. 

 Ver 1.08 Dec. 2008
   1. The command line specification and the drag & drop of the configuration file were enabled.
   2. The AGPS transmission timing was corrected.
   3. Non-text was not displayed in the sentence monitor display.
   4. The position where the dialog box was corrected.

 Ver 1.07 Dec. 2008
   1. The error display when the file was not found in the FTP server was corrected.

 Ver 1.06 Dec. 2008
   1. Supported an AGPS setting function

 Ver 1.05 Nov. 2008
   1. Corrected that VDOP was replaced with HDOP by "NMEA data" indication.

 Ver 1.04 Oct. 2008
   1. The number of digits below the decimal point in the Latitude/Longitude of the
      CSV and NMEA output was able to be specified.
   2. The number of digits below the decimal point in the Altitude/Speed of the CSV
      and NMEA output were able to be changed by the configuration file.

 Ver 1.03 Aug. 2008
   1. Rescue mode was added.
   2. NMEA output was added (Geoid option was added).
   3. When NMEA was returned instead of log data, retry request ahead of time.

 Ver 1.02 Jul. 2008
   1. It corresponded to Qstarz BT-Q1300.
   2. The receiving break off number of errors was changed from five times of the total to
      five times in each sector.
   3. When the locale was Japan, the font of default was changed to the MS Pgothic.
   4. The hint display was added.

 Ver1.01 May. 2008
   1. If NMEA2KMZ.EXE was starting, the file name was dropped.
   2. After it had downloaded it, the change of the CSV output option was enabled.
   3. The option of the CSV file output was added.
      1) "INDEX" is not output.
      2) Date and time are output to "TIME".

 Ver1.00  May. 2008
